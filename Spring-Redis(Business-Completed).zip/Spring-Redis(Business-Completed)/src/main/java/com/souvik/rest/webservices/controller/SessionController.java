package com.souvik.rest.webservices.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.souvik.rest.webservices.model.SessionDetails;
import com.souvik.rest.webservices.repository.SessionService;

@RestController
@RequestMapping("/session")
public class SessionController {
	
	@Autowired
	SessionService sessionService;
	
	@PostMapping
	public void saveStudentInformation(@RequestBody SessionDetails session) {
		sessionService.setSessionDetails(session);
	}

	
	@GetMapping(path = "{session_id}/{tab_id}")
	public SessionDetails fetchDetail(@PathVariable("session_id") String session_id,@PathVariable("tab_id") String tab_id) {
		return sessionService.getSessionDetails(session_id, tab_id);
	}

	

}
