package com.souvik.rest.webservices.model;

import java.io.Serializable;

import java.util.Date;

public class SessionDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	public String sessionId;
	public String tabId;
	public String sabreSessionId;
	public String execution;
	public Date createdTime;
	public Date lastAccessedTime;
	
	public Date getLastAccessedTime() {
		return lastAccessedTime;
	}

	public void setLastAccessedTime(Date lastAccessedTime) {
		this.lastAccessedTime = lastAccessedTime;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getTabId() {
		return tabId;
	}

	public void setTabId(String tabId) {
		this.tabId = tabId;
	}

	public String getSabreSessionId() {
		return sabreSessionId;
	}

	public void setSabreSessionId(String sabreSessionId) {
		this.sabreSessionId = sabreSessionId;
	}

	public String getExecution() {
		return execution;
	}

	public void setExecution(String execution) {
		this.execution = execution;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	@Override
	public String toString() {
		return "SessionDetails [sessionId=" + sessionId + ", tabId=" + tabId + ", sabreSessionId=" + sabreSessionId
				+ ", execution=" + execution + ", createdTime=" + createdTime + ", lastAccessedTime=" + lastAccessedTime
				+ "]";
	}







}
