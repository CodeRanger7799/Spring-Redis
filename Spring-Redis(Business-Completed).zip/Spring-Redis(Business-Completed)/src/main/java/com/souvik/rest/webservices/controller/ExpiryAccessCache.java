package com.souvik.rest.webservices.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.souvik.rest.webservices.model.SessionDetails;

@EnableScheduling
@Component
public class ExpiryAccessCache {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExpiryAccessCache.class);

	@Autowired
	SessionDAO sessionDAO;

	public static List<String> tabInserted = new ArrayList<String>();

	public List<String> getAllTabs() {
		return tabInserted;
	}

	public void addToTabInserted(String tabId) {
		tabInserted.add(tabId);
	}

	public void DeleteFromTab(String tabId) {
		tabInserted.remove(tabId);
	}

	@Scheduled(fixedDelay = 20000) // Setting it to 20 seconds
	public void FilterBasedonLastAccessedTime() {
		LOGGER.info("Scheduler Called");
		List<SessionDetails> allSessionDetails = new ArrayList<SessionDetails>();
		for (String c : tabInserted) {
			allSessionDetails.add(sessionDAO.getForCacheEviction(c));
		}
		CompareLastAccessedTime(allSessionDetails);
	}

	public void CompareLastAccessedTime(List<SessionDetails> allSession) {
		LOGGER.info("Scanning for eviction from Cache");
		for (SessionDetails sd : allSession) {
			Date startDate = sd.getLastAccessedTime();
			Date endDate = new Date();
			long duration = endDate.getTime() - startDate.getTime();
			long diffInSeconds = TimeUnit.MILLISECONDS.toSeconds(duration);// If the lastAccessedTime is more than 60
																			// seconds then it should be removed
			if (diffInSeconds >= 60) {
				LOGGER.info("Removing due to timeout: " + sd);
				sessionDAO.delete(sd);
			}

		}
	}

}
