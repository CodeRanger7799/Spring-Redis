package com.souvik.rest.webservices.controller;

import javax.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.souvik.rest.webservices.model.SessionDetails;

@Component
public class SessionDAO {
	private static final Logger LOGGER = LoggerFactory.getLogger(SessionDAO.class);
	private static final String TABLE_NAME = "Session";

	private RedisTemplate<String, Object> redisTemplate;

	@Autowired
	ExpiryAccessCache expiryCache;

	private HashOperations<String, String, SessionDetails> hashOperations;

	@Autowired
	public SessionDAO(RedisTemplate<String, Object> redisTemplate) {
		this.redisTemplate = redisTemplate;
	}

	@PostConstruct
	private void intializeHashOperations() {
		hashOperations = redisTemplate.opsForHash();
	}

	// @Cacheable(value = "session", key = "#tabId", unless = "#result == null")
	public SessionDetails get(String sessionId, String tabId) {
		LOGGER.info("--------------------get db called :" + tabId);
		return hashOperations.get(TABLE_NAME, tabId);
	}

	public SessionDetails getForCacheEviction(String tabId) {
		LOGGER.info("--------------------get db called :" + tabId);
		return hashOperations.get(TABLE_NAME, tabId);
	}

	public void save(SessionDetails sessison) {
		LOGGER.info("--------------------save db called :" + sessison.getTabId());
		hashOperations.put(TABLE_NAME, sessison.getTabId(), sessison);
	}

	@CachePut(value = "session", key = "#sessison.tabId", unless = "#result == null")
	public SessionDetails update(SessionDetails sessison) {
		LOGGER.info("--------------------update db called :" + sessison.getTabId());
		hashOperations.put(TABLE_NAME, sessison.getTabId(), sessison);
		// return hashOperations.get(TABLE_NAME, sessison.getTabId());// This is not
		// allowing to set the updated value to cache.
		return get(sessison.getSessionId(), sessison.getTabId());
	}

	@CacheEvict(value = "session", key = "#sessison.tabId")
	public void delete(SessionDetails sessison) {
		hashOperations.delete(TABLE_NAME, sessison.getTabId());
		expiryCache.DeleteFromTab(sessison.getTabId());
	}

}
