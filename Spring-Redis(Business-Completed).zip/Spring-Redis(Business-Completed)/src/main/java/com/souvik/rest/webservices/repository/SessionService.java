package com.souvik.rest.webservices.repository;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.stereotype.Component;

import com.souvik.rest.webservices.controller.ExpiryAccessCache;
import com.souvik.rest.webservices.controller.SessionDAO;
import com.souvik.rest.webservices.model.SessionDetails;

@Component
public class SessionService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SessionService.class);

	@Autowired
	SessionDAO repo;

	@Autowired
	ExpiryAccessCache expireCache;

	public SessionDetails getSessionDetails(String sessionId, String tabId) {
		SessionDetails session = repo.get(sessionId, tabId);

		if (null == session) {
		}
		session.setLastAccessedTime(new Date());
		repo.update(session);
		return session;

	}

	public void setSessionDetails(SessionDetails sessionSave) {
		try {
			sessionSave.setCreatedTime(new Date());
			sessionSave.setLastAccessedTime(new Date());
			repo.save(sessionSave);
			expireCache.addToTabInserted(sessionSave.getTabId()); // Whenever i am adding a data I am adding its tabId
																	// in the arrayList for Later retrieval
		} catch (Exception e) {
			LOGGER.error("", e);

		}
	}

	@Lookup
	public SessionDetails createSessionDetails() {
		return null;
	}

}