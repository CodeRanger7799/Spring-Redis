package com.souvik.rest.webservices.service;

import java.util.ArrayList;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.souvik.rest.webservices.model.Detail;
import com.souvik.rest.webservices.repository.DetailRepository;

@Service
public class DetailService {

	private final Logger LOG = LoggerFactory.getLogger(getClass());

	@Autowired
	DetailRepository detailRepository;

	public List<Detail> getAllStudent() {
		List<Detail> students = new ArrayList<Detail>();
		detailRepository.findAll().forEach(student -> students.add(student));
		return students;
	}

	@Cacheable("detail")
	public Detail getStudentById(int id) {
		LOG.info("Getting user with id: " + id);
		return detailRepository.findById(id).get();
	}

	public void saveOrUpdate(Detail student) {
		detailRepository.save(student);
	}

	public void delete(int id) {
		detailRepository.deleteById(id);
	}

}
